<div class="groupcontent groupcontent_pages">
            <div class="content">
              <h2>Reviews:</h2>                Please help our business by reviewing us online!<br><br>                Many people have found our nail salon through the Internet. It would really make a difference if you can say something nice about us. You may have to sign up for an account to post a review, but it is very quick and easy.
              <div class="reviewsus">Reviews us:</div>
              <div class="groupreviews_bt"><a class="review_bt yelp" href="http://www.yelp.com/biz/bella-lifestyle-nail-salon-and-spa-gambrills" target="_blank"></a><a class="review_bt pages" href="#" target="_blank"></a><a class="review_bt fb" href="https://www.facebook.com/BellaWaughChapel/timeline/" target="_blank"></a><a class="review_bt google" href="https://www.google.com.vn/search?q=Bella+Lifestyle+891+MD+Route+3+North+Gambrills%2C+MD+21054&amp;oq=Bella+Lifestyle+891+MD+Route+3+North+Gambrills%2C+MD+21054&amp;aqs=chrome..69i57.3559j0j7&amp;sourceid=chrome&amp;ie=UTF-8" target="_blank"></a></div>
              <div class="reviewsgroup">
                <div class="reviews">
                  <div class="reviewsimg"><img src="images/Faith_J.jpg" alt=""></div>
                  <div class="reviewsname"><span>Mark N.</span><br>Monterey, CA<br>5/30/2017</div>
                  <div class="reviewsyelp"><a href="https://www.yelp.com/biz/bella-lifestyle-nail-salon-and-spa-gambrills?sort_by=date_desc" target="_blank"><img src="images/reviews/yelp.png" alt=""></a></div>
                </div>
                <div class="reviewsstar"><img src="images/star.png" alt=""><img src="images/reviews/star.png" alt=""><img src="images/reviews/star.png" alt=""><img src="images/reviews/star.png" alt=""><img src="images/reviews/star.png" alt=""></div>
                <div class="reviewstxt">I just got my nails and toes done by Kim today and she is fantastic! She is so attentive, meticulous, and sweet--so ask for Kim next time you are in this beautiful classy Shop! I have been to many salons in the area but this one is by far the best and blows my mind from the cleanliness to the customer service. All the staff here are so nice. I'm officially hooked!</div>
              </div>
              <div class="reviewsgroup">
                <div class="reviews">
                  <div class="reviewsimg"><img src="images/Hanna_R.jpg" alt=""></div>
                  <div class="reviewsname"><span>Suzanne Wolcoff</span></div>
                  <div class="reviewsyelp"><a href="https://www.google.com/search?ludocid=16238856962558386631&amp;q=Bella%20Lifestyle%20Nail%20Salon%20%26%20Spa%20891%20MD%20Route%20Rd%203%20North%20Gambrills,%20Anne%20Arundel%20County,%20Maryland%2021054&amp;_ga=1.200841133.2039284145.1458738597#lrd=0x89b7ef8e2f482a8f:0xe15c025ecbabe1c7,1,," target="_blank"><img src="images/reviews/google.png" alt=""></a></div>
                </div>
                <div class="reviewsstar"><img src="images/star.png" alt=""><img src="images/reviews/star.png" alt=""><img src="images/reviews/star.png" alt=""><img src="images/reviews/star.png" alt=""></div>
                <div class="reviewstxt">Very nice facility, customer service, & painting of toes was flawless. Could of left hot towels on legs longer & let feet soak longer.</div>
              </div>
            </div>
          </div>