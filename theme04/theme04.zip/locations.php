<div class="groupcontent groupcontent_pages">
              <div class="content">
                <h2>Locations</h2>
                <!-- <div class="groupcontact"><a href="locations.html#san-ramon">San Ramon</a><a href="locations.html#pleasant-hill-map">Pleasant Hill</a><a href="locations.html#pleasanton-map">Pleasanton</a><a href="locations.html#walnut-creek-map">Walnut Creek</a><a href="locations.html#concord-map">Concord</a><a href="locations.html#danville-map">Danville</a></div><a name="san-ramon"></a> -->
                <div class="grouplocation">
                  <div class="location_title">Nails Salon</div>                         
                  123 ABC Street, VA 123 <br>
                  <a href="tel:(123) 456 - 7890 ">(123) 456 - 7890 </a><br><br>
                  <strong>Salon Hours:</strong><br>Monday-Friday: 9:00am-7:00pm<br>
                  Saturday: 9:00am-6:00pm<br>
                  Sunday: 10:00am-6:00pm
                  <div class="maps">
                  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2345.8770519046416!2d-117.95378818968437!3d33.745904118688756!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80dd27be9256e4fb%3A0xaa6fa85e0281e6d6!2s10161+Bolsa+Ave+%23207A%2C+Westminster%2C+CA+92683!5e0!3m2!1svi!2s!4v1535436330992" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
                  </div>
                </div><a name="pleasant-hill-map"></a>
                <!-- <div class="grouplocation">
                  <div class="location_title">Pleasant Hill</div>                        1420 Contra Costa Blvd. Pleasant hill, CA 94523<br><a href="tel:9256808600">(925) 680-8600</a><br><br><strong>Salon Hours:</strong><br>Monday-Friday: 9:30am-7:00pm<br>Saturday: 9:00am-6:00pm<br>Sunday: 10:00am-6:00pm
                  <div class="maps">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12583.299305253302!2d-122.060469!3d37.957876!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x852762eb942eaebd!2sBollinger+Nail+Spa!5e0!3m2!1svi!2s!4v1520911093410" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen=""></iframe>
                  </div>
                </div><a name="pleasanton-map"></a> -->
                <!-- <div class="grouplocation">
                  <div class="location_title">Pleasanton</div>                        310 Main Street Pleasanton, CA 94566<br><a href="tel:9254844300">(925) 484-4300</a><br><br><strong>Salon Hours:</strong><br>Monday-Friday: 9:00am-7:00pm<br>Saturday: 9:00am-6:00pm<br>Sunday: 10:00am-6:00pm
                  <div class="maps">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12634.300010127903!2d-121.8763701!3d37.6591946!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xc5c617aab16a5cea!2sBollinger+Nail+Salon!5e0!3m2!1svi!2s!4v1520911258281" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen=""></iframe>
                  </div>
                </div><a name="walnut-creek-map"></a>
                <div class="grouplocation">
                  <div class="location_title">Walnut Creek</div>                        1661 Mt. Diablo Blvd. Walnut Creek, CA 94596<br><a href="tel:9259382500">(925) 938-2500</a><br><br><strong>Salon Hours:</strong><br>Monday-Friday: 9:30am-7:00pm<br>Saturday: 9:00am-6:00pm<br>Sunday: 10:00am-6:00pm
                  <div class="maps">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12593.707748985411!2d-122.0623735!3d37.8970824!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x2f0c27c9e43c9520!2sBollinger!5e0!3m2!1svi!2s!4v1520911313845" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen=""></iframe>
                  </div>
                </div><a name="concord-map"></a>
                <div class="grouplocation">
                  <div class="location_title">Concord</div>                        2066 Salvio Street Concord, CA 94520<br><a href="tel:9258257800">(925) 825-7800</a><br><br><strong>Salon Hours:</strong><br>Monday-Friday: 9:30am-7:00pm<br>Saturday: 9:00am-6:00pm<br>Sunday: 10:00am-6:00pm
                  <div class="maps">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12580.003173416499!2d-122.0351391!3d37.9771108!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x5da3a37e1f297fe1!2sBollinger+Nail+Salon!5e0!3m2!1svi!2s!4v1520911392979" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen=""></iframe>
                  </div>
                </div><a name="danville-map"></a>
                <div class="grouplocation">
                  <div class="location_title">Danville</div>                        760 Camino Ramon Danville, CA 94526<br><a href="tel:9258385300">(925) 838-5300</a><br><br><strong>Salon Hours:</strong><br>Monday-Friday: 9:00am-7:00pm<br>Saturday: 9:00am-6:00pm<br>Sunday: 10:00am-6:00pm
                  <div class="maps">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12608.692019393413!2d-121.9904309!3d37.8094165!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x23066b72054f3b38!2sBollinger+Nail+Salon!5e0!3m2!1svi!2s!4v1520911460099" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen=""></iframe>
                  </div>
                </div> -->
              </div>
            </div>