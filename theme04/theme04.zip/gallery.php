<div class="groupcontent groupcontent_pages" >
<div class="content">
    <h2>Our Gallery</h2>
    <div id="gallery">
    <?php  for($i=1;$i<=18;$i++){?>
        <a href="images/gallery/<?php echo $i?>.jpg" rel="shadowbox[<?php echo $i?>]"><img src="images/gallery/<?php echo $i?>.jpg" alt="salon img01" title="salon img01" /></a>
    <?php } ?>
        <!-- <a href="images/gallery/01.jpg" rel="shadowbox[1]"><img src="images/thumb/01.jpg" alt="img01" title="img01"></a>
        <a href="images/gallery/03.jpg" rel="shadowbox[1]"><img src="images/thumb/03.jpg" alt="img03" title="img03"></a>
        <a href="images/gallery/04.jpg" rel="shadowbox[1]"><img src="images/thumb/04.jpg" alt="img04" title="img04"></a><a href="images/gallery/05.jpg" rel="shadowbox[1]"><img src="images/thumb/05.jpg" alt="img05" title="img05"></a><a href="iamages/gallery/06.jpg" rel="shadowbox[1]"><img src="images/thumb/06.jpg" alt="img06" title="img06"></a><a href="images/gallery/07.jpg" rel="shadowbox[1]"><img src="images/thumb/07.jpg" alt="img07" title="img07"></a><a href="images/gallery/08.jpg" rel="shadowbox[1]"><img src="images/thumb/08.jpg" alt="img08" title="img08"></a><a href="images/gallery/09.jpg" rel="shadowbox[1]"><img src="images/thumb/09.jpg" alt="img09" title="img09"></a><a href="images/gallery/10.jpg" rel="shadowbox[1]"><img src="images/thumb/10.jpg" alt="img10" title="img10"></a><a href="images/gallery/11.jpg" rel="shadowbox[1]"><img src="images/thumb/11.jpg" alt="img11" title="img11"></a><a href="images/gallery/12.jpg" rel="shadowbox[1]"><img src="images/thumb/12.jpg" alt="img12" title="img12"></a><a href="images/gallery/14.jpg" rel="shadowbox[1]"><img src="images/thumb/14.jpg" alt="img14" title="img14"></a><a href="images/gallery/15.jpg" rel="shadowbox[1]"><img src="images/thumb/15.jpg" alt="img15" title="img15"></a><a href="images/gallery/16.jpg" rel="shadowbox[1]"><img src="images/thumb/16.jpg" alt="img16" title="img16"></a></div> -->
</div>
</div>