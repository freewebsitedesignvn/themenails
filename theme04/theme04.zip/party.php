<div class="groupcontent groupcontent_pages" >
<div class=" content">
    <h2>Party</h2>
    <div class="groupabout">
        <div class="about_title">Host A Party</div>
        <div class="about_img"><img src="images/party01.jpg" alt="party"style="width:100%;"></div>
        <div style="font-size:13pt;">For birthdays, bridal showers, corporate parties or friends who just want to have a unique and fun get together, arrange a party at Nail Salon today.<br><br><b>Come, Relax and Enjoy!</b></div>
    </div>
</div>
</div>