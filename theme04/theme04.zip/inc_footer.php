<div class="groupfooter">
    <div class="footer">
    <div class="copyright">Copyright © Nail Salon<span><a href="policy">Privacy policy</a></span></div>
    <div class="social">
        <a href="https://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook"></a>
        <a href="https://www.google.com.vn/" target="_blank"><img src="images/googleplus.png" alt="Google Plus"></a>
        <a href="http://www.yelp.com/biz/" target="_blank"><img src="images/yelp.png" alt="Yelp"></a></div>
    </div>
</div>