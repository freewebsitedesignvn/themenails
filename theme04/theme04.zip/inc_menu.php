<div class="header_m">
                <div class="groupmenu_m">
                  <ul>
                    <li id="call_m"><a href="locations.html"><span>Call</span></a></li>
                    <li id="email_m"><a href="services.html"><span>Services</span></a></li>
                    <li id="direction_m"><a href="locations.html"><span>Direction</span></a></li>
                    <li id="subbar_m"><a href="sign-up.html"><span>Sign Up</span></a></li>
                  </ul>
                  <ul>
                    <li id="egift_m"><a href="e-gift.html"><span>E-Gift</span></a></li>
                    <li id="services_m"><a href="services.html"><span>Services</span></a></li>
                  </ul>
                </div>
              </div>
              <div class="groupmenu">
                <div id="menu">
                  <ul class="menu_m">
                    <li class="menuimg">Menu</li>
                    <li><a class="hvr-float-shadow selected" href="?p=home">Home</a>
                    </li>
                    <li><a class="hvr-float-shadow" href="?p=about-us">About Us</a>
                    </li>
                    <li><a class="hvr-float-shadow" href="?p=services">Services</a>
                    </li>
                    <li><a class="hvr-float-shadow" href="?p=party">Party</a>
                    </li>
                    <li><a class="hvr-float-shadow" href="?p=gallery">Gallery</a>
                    </li>
                    <li><a class="hvr-float-shadow" href="?p=promotions">Promotions</a>
                    </li>
                    <!-- <li><a class="hvr-float-shadow" href="?p=e-gift">E-Gift</a>
                    </li> -->
                    <li><a class="hvr-float-shadow" href="?p=locations">Locations</a>
                    </li>
                    <li><a class="hvr-float-shadow" href="?p=contact">contact</a>
                    </li>
                  </ul>
                </div>
              </div>