<div class="groupcontent " >
<div class="groupbanner">
    <img src="images/banner1.jpg" alt="banner">
    <div class="banner" id="banner1">
        <div class="banner_txt" id="banner_txt1">Welcome to <span>Nail Salon</span></div>
    </div>
    <div class="banner" id="banner2">
        <div class="banner_txt" id="banner_txt2">PROFESSIONAL<span>Care For Your Nails</span></div>
    </div>
    <div class="banner" id="banner3">
        <div class="banner_txt" id="banner_txt3">Voted #1<span>Nail Salon</span></div>
    </div>
    <div class="banner" id="banner4">
        <div class="banner_txt" id="banner_txt4">ELEGANT<span> & Relaxing Environment</span></div>
    </div>
    <div class="banner" id="banner5">
        <div class="banner_txt" id="banner_txt5">ULTIMATE<span> Spa Experience</span></div>
    </div>
</div>
<div class="groupnext">
    <div class="nextbox">
        <div class="next" id="next1"></div>
        <div class="next" id="next2"></div>
        <div class="next" id="next3"></div>
        <div class="next" id="next4"></div>
        <div class="next" id="next5"></div>
    </div>
</div>
</div>