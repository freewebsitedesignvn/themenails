<link href="https://fonts.googleapis.com/css?family=Josefin+Sans:400,300" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="./css/core.min.css">
    <link rel="stylesheet" href="./css/main.css">
    <script src="./js/core.js"></script>
    <script src="./js/main.js"></script>