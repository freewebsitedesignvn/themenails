<div class="groupcontent groupcontent_pages" >
<div class=" content">
    <h2>Welcome to Nail Salon!!!</h2>
    <div class="about_img"><img src="images/about01.jpg" alt="about" style="width:100%;"></div>
    <div class="groupabout">
        <div class="about_title">About Us</div>                        
        Opened since 1998 with a single location in San Ramon, California. Nail Salon was established with the vision of providing superior service to our customers in a relaxing, upscale environment.<br><br>Currently, we have six salons located in San Ramon, Pleasant Hill, Walnut Creek, Pleasanton, Concord and Danville.
    </div>
    <div class="groupabout">
        <div class="about_title">What you can come to expect…</div>                        A salon where you receive the finest nail care in a comfortable and inviting atmosphere. We strive to assure that our customers receive the very best in personalized and professional nail care services.<br><br>                        Our friendly, licensed professionals provide a wide selection of nail enhancements in a carefully maintained hygienic environment. We also offer complete manicure and pedicure services.
    </div>
</div>
</div>