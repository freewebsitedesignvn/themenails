
            <div class="groupcontent">
                <div class="content">
                    <h2>Our Services</h2>

                    
                    <div id="ser1" class="groupservices">
                        <a name="nails-enhancement"></a>
                        <div class="servicestitle">Nails Enhancement</div>
                        <div class="servicesbox">
                            <div class="servicesimg">
                                
                                <img src="images/services/spapackagesmanicures/1.png" alt="Nails Enhancement 1" class="pedi_img" />
                                <!-- <img src="images/services/02.jpg" alt="Nails Enhancement 2" class="pedi_img" />
                                <img src="images/services/03.jpg" alt="Nails Enhancement 3" class="pedi_img clear_img" />
                                <img src="images/services/04.jpg" alt="Nails Enhancement 4" class="pedi_img clear_img" />
                                <img src="images/services/05.jpg" alt="Nails Enhancement 5" class="pedi_img clear_img" />
                                <img src="images/services/06.jpg" alt="Nails Enhancement 6" class="pedi_img clear_img" />
                                <img src="images/services/07.jpg" alt="Nails Enhancement 7" class="pedi_img clear_img" /> -->
                            </div>
                            <div class="title_right">Full set /Fill In</div>
                            <div class="services_l">  
                                <div class="grouprow">                              
                                    <!--<div class="rowtitle">Full Set - Warranty Powder Non Yellow</div>-->
                                    <!-- <div class="row" style="color:#61b85a;">If add on gel polish<div class="price">$15</div>
                                        <div class="rownote">This price if you get service with full set gel or fill gel.</div>
                                    </div>
                                    <div class="row" style="color:#61b85a;">Add on paraffin dip<div class="price">$8</div></div> -->
                                    <div class="row">Acrylic Powder<div class="price">$30 &amp; Up/ $20 &amp; Up</div></div>
                                    <div class="row">UV clear Gel Powder<div class="price">$40 &amp; Up/ $30 &amp; Up</div></div>
                                    <div class="row">Sculpture Acrylic (no nails tip)<div class="price">$45 &amp; Up/ $20 &amp; Up</div></div>
                                    <div class="row">Sculpture Gel Powder (no nails tip)<div class="price">$55 &amp; Up/ $30 &amp; Up</div></div>

                                    <div class="row">UV Liquid Gel / Silk Wrap<div class="price">$50 &amp; Up/ $35 &amp; Up</div></div>
                                    <div class="row">Pink &amp; White OPI<div class="price">$60</div>
                                        <div class="rownote"> Fill pink $30 / fill pink &amp; white $50</div>
                                    </div>
                                    <div class="row">Dip SNS for Nature Nails<div class="price">$45</div></div>
                                    <div class="row">Dip SNS Pink &amp; White for Nature Nails<div class="price">$50</div></div>
                                    <div class="row">Dip SNS<div class="price">$55 &amp; Up/ $45 &amp; Up</div></div>
                                    <div class="row">Dip SNS Pink &amp; White<div class="price">$60 &amp; Up/ $40 &amp; Up-$50 &amp; Up</div></div>
                                    <div class="row">Pink &amp; White Liquid Gel<div class="price">$70 &amp; Up/ $35 &amp; Up-$60 &amp; Up</div></div>
                                    <div class="row">Ombre<div class="price">$60 &amp; Up/ $30 &amp; Up-$50 &amp; Up</div></div>
                                </div>

                                <div class="grouprow">                              
                                    <div class="rowtitle">Solar Color Nail</div>
                                    <div class="row">1 Color tip<div class="price">$60 &amp; up (Fill $30 | $50 &amp; up)</div></div>
                                    <div class="row">2 Colors tip<div class="price">$70 &amp; up (Fill $30 | $60 &amp; up)</div></div>
                                    <div class="row">3 Color tip<div class="price">$85 &amp; up (Fill $30 | $75 &amp; up)</div></div>
                                </div>

                                <!--<div class="grouprow">                              
                                    <div class="rowtitle"> Fill In</div>                                   
                                    <div class="row">Acrylic Powder<div class="price">$18</div></div>
                                    <div class="row">UV clear Gel Powder<div class="price">$25</div></div>
                                    <div class="row">UV Liquid Gel / Silk Wrap<div class="price">$30</div></div>
                                    <div class="row">Pink &amp; White OPI Solar Powder<div class="price">$40 - $27 (fill pink)</div></div>
                                    <div class="row">Pink &amp; White Liquid Gel LCN<div class="price">$45 - $30 (fill pink)</div></div>
                                    <div class="row">Pink &amp; White Liquid Gel IMPERIAL<div class="price">$60 - $40 (fill pink)</div></div>
                                    <div class="row">Dip Diamond Fill Pink<div class="price">$27</div></div>
                                    <div class="row">Dip Diamond Fill Pink &amp; White<div class="price">$40</div></div>
                                    <div class="row">SNS Dipping Powder<div class="price">$30</div></div>
                                    <div class="row">SNS P&amp;W<div class="price">$45</div></div>
                                </div>-->

                                <div class="grouprow">                              
                                    <div class="rowtitle">Hand Design</div>  
                                    <div class="row">2 Fingers<div class="price">$7 &amp; up</div></div>
                                    <div class="row">4 Fingers<div class="price">$12 &amp; up</div></div>
                                    <div class="row">10 Fingers<div class="price">$20 &amp; up</div></div>
                                    <div class="row">French/French American/Color Tip<div class="price">$7</div></div>                                   
                                </div>

                                <!-- <div class="grouprow">                              
                                    <div class="rowtitle">Special Design – 3D Design</div>
                                    <div class="row">2 Fingers 3D design<div class="price">$15 &amp; up</div></div>    
                                    <div class="row">4 Fingers 3D design<div class="price">$25 &amp; up</div></div>
                                    <div class="row">10 Fingers 3D design<div class="price">$45 &amp; up</div></div>                               
                                </div>

                                <div class="grouprow">                              
                                    <div class="rowtitle">Polish Change</div>
                                    <div class="row">Polish change with regular Color
                                        <ul>
                                            <li>Hand (natural nails)<div class="price">$10</div></li>
                                            <li>Feet (natural nails)<div class="price">$13</div></li>
                                            <li>Artificial Nails (hand)<div class="price">$13</div></li>
                                        </ul>
                                    </div> 
                                    <div class="row">Polish change if French or French American or color tip
                                        <ul>
                                            <li>Hand (natural nails)<div class="price">$13</div></li>
                                            <li>Feet (natural nails)<div class="price">$15</div></li>
                                            <li>French for Artificial Nails (hand)<div class="price">$15</div></li>
                                            <li>Color change for Gel Polish (hand or feet)<div class="price">$25</div></li>
                                            <li>Color change for Gel French or gel color tip (hand or feet)<div class="price">$30</div></li>
                                        </ul>
                                    </div>                                                                   
                                </div>

                                <div class="grouprow">                              
                                    <div class="rowtitle">Add On</div> 
                                    <div class="row">Cut Down<div class="price">$3</div></div>
                                    <div class="row">Repair 1 nails: acrylic / gel / pink white<div class="price">$4 | $5 | $7 &amp; up</div></div> 
                                    <div class="row">French tip / French American tip / color tip / crystal tip<div class="price">$5</div></div>  
                                    <div class="row">Paraffin dip for hand<div class="price">$8</div></div> 
                                    <div class="row">Paraffin for feet<div class="price">$13</div></div> 
                                    <div class="row">Soak off Artificial Nails<div class="price">$10</div></div>  
                                    <div class="row">Callus Treatment for Feet<div class="price">$10</div></div>  
                                    <div class="row">Hot Stone Massage for Hand<div class="price">$15 - 10min | $20 -15min</div></div>
                                    <div class="row">Hot Stone Massage for Feet<div class="price">$15 - 10min | $20 -15min</div></div> 
                                    <div class="row">Soak off Gel Polish with manicure<div class="price">$5</div></div> 
                                    <div class="row">Soak off Gel Polish without manicure<div class="price">$10</div></div>  
                                    <div class="row">Clean / Cut Cuticle<div class="price">$8</div></div>  
                                    <div class="row">Cut &amp; Shape Nails &amp; Clean Cuticle<div class="price">$12</div></div>                                
                                </div> -->

                           </div>
                        </div>
                    </div>

                    <div id="ser2" class="groupservices">
                        <a name="manicure"></a>
                        <div class="servicestitle">Manicure</div>
                        <div class="servicestitle_note">All these manicure include cut, shaping, clean, hot towel, and polish.</div>
                        <div class="servicesbox">
                            <div class="servicesimg">
                                <img src="images/services/additionalservices/1.png" alt="Manicure" class="pedi_img" />
                                <!-- <img src="images/services/09.jpg" alt="Manicure" class="pedi_img" /> -->
                            </div>
                            <div class="services_l">  
                                <div class="grouprow">  
                                    <div class="row">Gel Polish extra<div class="price">$20</div></div>  
                                    <div class="row">Cat eyes gel extra<div class="price">$27</div></div>  
                                    <div class="row">Dip paraffin for hand extra<div class="price">$8</div></div>   
                                    <div class="row">Design 2 nail extra<div class="price">$7</div></div>  


                                    <div class="rowtitle">NATURAL PRODUCTS for MANICURE</div>   
                                    <div class="row">Natural nuskin manicure<div class="price">$30</div>
                                        <div class="rownote">Shapping, cut, clean, scrub exfoliation, mask, warm cream massage, hot towel, polish. Exfoliating with liquid lufra For soft, supple, younf-looking skin, use this invigorating soap-free cleanser which exfoliates dead skin cells with ground walnut shells, then moisturises with aloe vera, making your skin glow.</div>
                                    </div>    
                                    <div class="row">ICE dancer healthy manicure<div class="price">$40</div>
                                        <div class="rownote">Shapping, cut, clean cuticle, exfoliation with liquid lufra. For soft, supple, young-looking skin, use this invigorating soap-free cleanser which exfoliatrs dead skin cells with ground walnur shells, then moisturizer with aloe vera, making your hands. Whether you're working or playing, times spent on your hand can leave your hands feeling exhausted. This non-sticky, quick-absorbes gel cools and soothes tired achy hands. Formulmated with a refreshing combination of horse chestmut, peppermint oil and wild mint your hands will feel reju-venates as this gel melts into your skin. Extended massage longer ewith Baobab butter Nourish your skin with moisturising shea butter and the fruit of the Africa baobab tree. These time-tested ethnobotanicals promote smooth, supple skin that stays touchably soft all day while enhancing skin resiliency for even softer skin tomorrow. </div>
                                    </div>    
                                    <div class="row">Fire worker healthy manicure<div class="price">$50</div>
                                        <div class="rownote">Shapping, cut, cleaning cuticle, wxfoliation with liquid lufra For Soft, supple, young-looking skin, user this invigarating soap-free cleanser which exfoliates dead skin cells with ground walnut shells, then moisturizer with aloe vera, amling your skin glow. Epoch fire walker products is specifically formulated to give the nourishment and treatment your hand need. Soothes and rejuvenates them after a long day. Extended hand massage and warm stone massage with Baobab butter Nourish your skin with moisturising shea and the fruit of the African baobab tree. Theae time-tested ethnobatanicals promote smooth, supple skin that stays touchbaly soft all day while enhancing skin resiliency for even softer skin tomorrow paraffin dip.</div>
                                    </div>    
                                    <!-- <div class="row">Basic Manicure <div class="price">$16</div>
                                        <div class="rownote"> Shapping, cut, clean cutlcle , massages, hot towel, regular polish.</div>
                                    </div>       
                                    <div class="row">Basic gel manicure without paraffin dip <div class="price">$36</div></div>                                               
                                     
                                    
                                    <div class="row">Classic Pedicure + Manicure + Shellac Gel
                                        <ul>
                                            <li>No Dip Paraffin<div class="price">$52</div></li>
                                            <li>Dip Parraffin<div class="price">$57</div></li>
                                        </ul>
                                    </div>
                                    <div class="row">Classic Manicure and pedicure <div class="price">$37</div></div>
                                    <div class="row">Classic Manicure<div class="price">$16</div></div>
                                    <div class="row">Hot cream / Oil Manicure<div class="price">$20</div></div>
                                    <div class="row">Purple Sea Salt Manicure<div class="price">$27</div></div>
                                    <div class="row">Silky Milk &amp; Honey Spa Manicure<div class="price">$25</div>
                                        <div class="rownote">Shapping, cut, clean cuticle, milk honey scrub exfoliate, menthol mask, hydrating butter milk masage, hot towel, regular polish.</div>
                                    </div>
                                    <div class="row">ORGANIC Spa Manicure <div class="price">$28</div></div>
                                    <div class="row">GEL Manicure
                                        <ul>
                                            <li>No Dip Paraffin <div class="price"> $30</div></li>
                                            <li>Dip Paraffin<div class="price">$36</div></li>
                                        </ul>
                                    </div>
                                    <div class="row">IMPERIAL Spa Manicure<div class="price">$35</div>
                                        <div class="rownote">Shapping, cut, clean cuticle, scrub exfolistion, mask, warm cream massage, hot towel, DIP paraffin, regular polish. You will be selected following the scrent: tanerinr, white tea, colada sparkle, grapefruit, vanila, milk &amp; honey, chery bing, lemongrass &amp; green tea, mandarin &amp; mango, lavender, pomergranate, coconut milk, tropical citrus. Massage with hot stone.</div>
                                    </div>
                                    <div class="row">GUAVA PASSION<div class="price">$38</div></div>
                                    <div class="row">PARADISAL DELUXE Manicure<div class="price">$40</div></div>
                                    <div class="row">ALMOND &amp; PEARL Mask Spa Manicure<div class="price">$40</div></div>
                                    <div class="row">OCEAN Spa manicure<div class="price">$40</div></div>
                                    <div class="row">HEAVEN on EARTH Manicure<div class="price">$45</div></div>
                                    <div class="row">Detox Spa Manicure<div class="price">$50</div></div>
                                    <div class="row">VIP SIGNATURE Manicure<div class="price">$60</div>
                                        <div class="rownote">Special soak your hand in milk &amp; honey soak mix scented flower, shapping, cut, clean cuticle, exfoliation your hand with liquid lufra For soft, supple, young-looking skin, use this invigorating soap-free cleanser which aloe vera, making your skin glow, collagen mask for your hand, 30 minitus massage with baobab butter and essence oil for your hand &amp; arm, baobab butter Nourish your skin with moisturising shea butter and the fruit of the African baobab tree. These time-tested ethnobotanicals promote smooth, supple skin that stays touchbaly soft all day while enhancing skin resilliency for even soften skin tomorrow, extended hot stone massage, hot towels, polish.</div>
                                    </div> -->
                                </div>
                           </div>
                        </div>
                    </div>

                    <div id="ser3" class="groupservices">
                        <a name="pedicure"></a>
                        <div class="servicestitle">Pedicure</div>
                        <div class="servicestitle_note">All these pedicure include cut, shaping, clean, hot towel, and polish.</div>
                        <div class="pedicure_note">
                            <div class="pedicureimg">
                                <!-- <img src="images/services/acrylic/1.jpg" alt="Pedicure" style="max-width: 230px;" /> -->
                            </div>
                            Our pedicure tubs are pipe-less to ensure clean and save water. Medical grate sterilizers ansani-tablet-packaged hospital strength anti-bacterial products are utilized for additional safety precautions
                            <br/>When you taking the pedicure, our spa will provide SANI tablet to protect clean and kill germ while you are enjoying pedicure. Sani-Tablet is a specially formulated product for portable and whirlpool foot baths that eliminated cross contaminations caused by microorganism such as bacteria, fungi, and viruses. Sani-Tablet has passed AOAC spa disinfection and sanitation tests. In EPA approved lab tests, it killed 99.99% bacteria, viruses and athlete’s foot fungus. Sani-Tablet protects clients from germs and virus. All it takes is one table dropped into the water before you soak your feet in the foot bath. To disinfect the whirlpool spa water, simply drop one Sani-Tablet in foot spa water, Agitate go dissolve.
                        </div>
                        <div class="servicestitle_note">All these pedicure include cut, shaping, clean, hot towel &amp; polish. If add on callus treatment + $7.00</div>
                        <div class="servicesbox">
                            <div class="servicesimg">
                                <img src="images/services/acrylic/1.jpg" alt="Pedicure" class="pedi_img" />
                                <!-- <img src="images/services/11.jpg" alt="Pedicure" class="pedi_img" /> -->
                            </div>
                            <div class="services_l">  
                                <div class="grouprow"> 
                                    <div class="row">Gel Polish extra<div class="price">$20</div></div>  
                                    <div class="row">Dip paraffin for feet extra<div class="price">$13</div></div>  
                                    <div class="row">Add callus treatment extra<div class="price">$10</div></div>   
                                    <div class="row">Design 2 nail extra<div class="price">$7</div></div>  

                                    <div class="rowtitle">NATURAL PRODUCTS for PEDICURE</div>   
                                    <div class="row">SMOOTH Natural nuskin pedicure<div class="price">$45</div>
                                        <div class="rownote">Shapping, cut, clean cuticle, including callus treatment if need, warm cream massage, hot towel, regular polish. Exfoliating with liquid lufia. For soft, supple, young-looking skin, use this invigorating soap-free cleanser which exfoliates dead skin cells with ground walnut shells, then moisturies with aloe vera, making your skin glow. Light body moisturising and nourishing lotion. Give your skin a welcone moisture boost with this superior body lotion containing a rich blend of aloe vera and highly effective moisture-binding humestant, NaPCA for soft, supple skin. This forulation very easily, and does't feel greasy after applycation.</div>
                                    </div>    
                                    <div class="row">ICE dancer healthy pedicure<div class="price">$60</div> </div>    
                                    <div class="row">Fire worker healthy pedicure<div class="price">$75</div></div>  

                                    <div class="row">Basic Pedicure<div class="price">$30</div></div>
                                    <div class="row">Classic Pedicure + Manicure + Shellac Gel
                                         <ul>
                                            <li>No Dip Paraffin<div class="price">$52</div></li>
                                            <li>Dip Parraffin<div class="price">$57</div></li>
                                         </ul>
                                     </div>
                                    <div class="row">Classic Pedicure<div class="price">$30</div></div>
                                    <div class="row">Runner Pedicure<div class="price">$40</div></div>
                                    <div class="row">Purple Sea Salt Pedicure<div class="price">$40</div></div>
                                    <div class="row">Mandarin &amp; White Tea Mask<div class="price">$40</div></div>
                                    <div class="row">Jelly Pedicure<div class="price">$45</div></div>
                                    <div class="row">Silky Milk &amp; Honey Spa Pedicure<div class="price">$50</div></div>
                                    <div class="row">ORGANIC Spa Pedicure<div class="price">$50</div></div>
                                    <div class="row">SUMMER DELUXE Pedicure<div class="price">$55</div></div>
                                    <div class="row">IMPERIAL Spa Pedicure<div class="price">$65</div></div>
                                    <!-- <div class="row">Guava Passion<div class="price">$68</div></div>
                                    <div class="row">PARADISAL DELUXE Pedicure<div class="price">$75</div></div>
                                    <div class="row">ALMOND &amp; PEARL Mask Spa Pedicure<div class="price">$75</div></div>
                                    <div class="row">OCEAN Spa Pedicure<div class="price">$80</div></div>
                                    <div class="row">HEAVEN on EARTH Pedicure<div class="price">$85</div></div>
                                    <div class="row">VIP SIGNATURE Pedicure<div class="price">$100</div></div>
                                    <div class="row">FOOT DETOX PEDICURES SERVICES:
                                        <ul>
                                            <li>IONIC FOOT DETOX<div class="price">$50</div></li>
                                            <li>FOOT DETOX AND A PERFECT PEDICURE<div class="price">$120</div></li>
                                        </ul>
                                    </div>
                                    <div class="row">Basic manicure + Basic pedicure<div class="price">$40</div></div>
                                    <div class="row">Basic gel manicure + Basic pedicure<div class="price">$60</div></div>
                                    <div class="row">Basic gel manicure + Basic pedicure + gel polish for toes<div class="price">$80</div></div>
                                    <div class="row">If add French gel<div class="price">$25</div></div> -->
                                </div>
                           </div>
                        </div>
                        <!-- <div style=" overflow:hidden">
                        <div class="servicestitle1">Heaven On Earth Pedicure</div>
                        <div class="img_left">
                        <img  src="images/services/pedicure/photo-1.jpg" width="100%" alt="" />
                        </div>
                        <div class="img_left1">
                        <img  src="images/services/pedicure/photo-3.jpg" width="100%" alt=""/>
                        </div>
                        <div class="img_right">
                        <img  src="images/services/pedicure/photo-2.jpg" width="100%" alt="" />
                        </div>
                        </div>
                        <div style=" overflow:hidden; margin-top:20px;" >
                        <div class="servicestitle1">Imperial Spa Pedicure</div>
                        <div class="img_left">
                        <img  src="images/services/pedicure/photo-4.jpg" width="100%" alt="" />
                        </div>
                        <div class="img_left1">
                        <img  src="images/services/pedicure/photo-5.jpg" width="100%" alt="" />
                        </div>
                        </div>
                        <div style=" overflow:hidden; margin-top:20px;" >
                        <div class="servicestitle1">Vip Signature Pedicure</div>
                        <div class="img_left">
                        <img  src="images/services/pedicure/photo-6.jpg" width="100%" alt="" />
                        </div>
                        <div class="img_left1">
                        <img  src="images/services/pedicure/photo-8.jpg" width="100%" alt="" />
                        </div>
                        <div class="img_right">
                        <img  src="images/services/pedicure/photo-7.jpg" width="100%" alt="" />
                        </div>
                        </div> -->
                    </div>

                    <!--<div class="groupservices">
                        <a name="service-for-men"></a>
                        <div class="servicestitle">Service for Men</div>  
                        <div class="servicesbox">
                            <div class="servicesimg">
                                <img src="images/services/12.jpg" alt="Service for Men" class="pedi_img"/>
                                <img src="images/services/13.jpg" alt="Service for Men" class="pedi_img"/>
                                <img src="images/services/14.jpg" alt="Service for Men" class="pedi_img clear_img"/>
                                <img src="images/services/15.jpg" alt="Service for Men" class="pedi_img clear_img"/>
                            </div>
                            <div class="services_l">  
                                <div class="grouprow"> 
                                    <div class="rowtitle">Manicure</div>
                                    <div class="row">MEN’s Active Manicure<div class="price">$18</div>
                                        <ul>
                                            <li>Cut, shape, clean, exfoliated with lemon sea salt, massage, hot towel.</li>
                                        </ul>
                                    </div>
                                    <div class="row">MEN’s Executive Deluxe Manicure<div class="price">$35</div>
                                        <ul>
                                            <li>Cut, shape, clean, exfoliated with COOLING mint scrub or purple sea salt or choose scrubs in AROMA SPA MANICURE, Menthol mask, hot lotion massage, hot towel.</li>
                                        </ul>
                                    </div>
                                    <div class="row">SUPPER MEN’S PARADISAL DELUXE Manicure<div class="price">$45</div>
                                        <ul>
                                            <li>Cut, shape, clean, exfoliated with Earth warming scrub, Earth moisture masque &amp; hot stone massage with Earth hydrating vitamins & mineral lotion, paraffin treatment, hot towel.</li>
                                        </ul>
                                    </div>                                  
                                </div>

                                <div class="grouprow"> 
                                    <div class="rowtitle">Pedicure</div>
                                    <div class="row"> MEN’s Active Pedicure<div class="price">$35</div>
                                        <ul>
                                            <li>Cut, shape, clean, exfoliated with lemon sea salt, hot lotion, massage, hot towel.</li>
                                        </ul>
                                    </div>
                                    <div class="row">MEN’s Executive Pedicure<div class="price">$50</div>
                                        <ul>
                                            <li>Special soak, cut, clean, remove dry skin and callus treatment, scrub, mask, nourish warm cream massage, hot towel. Customers will selected following the scents organic: <span style="color:#656565; font-weight:bold;">Lemongrass &amp; Green Tea; Mandarin &amp; Mango Tropical Citrus; Lavender; English Rose; Ginder Lime; Pemergrate &amp Limel Tuscan Citrus; Vanilla Aloe; Colada Sparkle; Berry Berry; Exotic Mango; Cherry Bing.</span></li>
                                        </ul>
                                    </div>
                                    <div class="row">SUPPER MEN’S PARADISAL DELUXE Pedicure<div class="price">$75</div>
                                        <ul>
                                            <li>Cut, shape, clean, exfoliated with Earth warming scrub, Earth moisture masque &amp; hot stone massage with Earth hydrating vitamins & mineral lotion, paraffin treatment, hot towel.</li>
                                        </ul>
                                    </div>                                  
                                </div>

                                <div class="grouprow"> 
                                    <div class="rowtitle">Facial For Men</div>
                                    <div class="row">Gentleman's Facial<div class="price">$50 | 30min --- $70 | 50min (Include massage for face)</div>
                                        <ul>
                                            <li>We will help you select the perfect facial for your particular skin type and condition, incorporating exfoliationg. Hydration and deep pore cleansing as necessary. Our flagship hydradermie customize for a man’s skin. This treatment includes deep cleansing, exfoliation oxygenation and extraction to thoroughly clean skin and remove surface inpurites and dullness. Next, a relaxing massage performed on neck, shoulder, and face to improve circulation while relaxing tense muscles. A mask is then applied to tighten pores, leaveing skin and beard area soft and refreshed. Finishing off with a moisturizer to protect and soften.</li>
                                        </ul>
                                    </div>
                                    <div class="row">Back Facial<div class="price">$65 | 30 min --- $100 | 60 min</div>
                                        <ul>
                                            <li>Special soak, cut, clean, remove dry skin and callus treatment, scrub, mask, nourish warm cream massage, hot towel. Customers will selected following the scents organic: <span style="color:#656565; font-weight:bold;">Lemongrass &amp; Green Tea; Mandarin &amp; Mango Tropical Citrus; Lavender; English Rose; Ginder Lime; Pemergrate &amp Limel Tuscan Citrus; Vanilla Aloe; Colada Sparkle; Berry Berry; Exotic Mango; Cherry Bing.</span></li>
                                        </ul>
                                    </div>                                                                
                                </div>

                           </div>
                        </div>
                    </div>-->

                    <div id="ser4" class="groupservices">
                        <a name="kids-services"></a>
                        <div class="servicestitle">Kid’s Services</div>                       
                        <div class="servicesbox">
                            <div class="servicesimg">
                                <img src="images/services/kid/1.png" alt="Kid’s Services" class="pedi_img" />
                                <!-- <img src="images/services/17.jpg" alt="Kid’s Services" class="pedi_img" /> -->
                            </div>
                            <div class="services_l">  
                                <div class="grouprow"> 
                                    <div class="row">Basic Manicure<div class="price">$10</div>
                                         <ul>
                                            <li>Cut, Clean, Lotion, and Polish</li>
                                         </ul>
                                     </div>
                                    <div class="row">Little Miss Manicure<div class="price">$20</div>
                                        <ul>
                                            <li>Cut, Clean, Milk &amp; Honey Butter Massage, Warm Towel, and Polish</li>
                                        </ul>
                                    </div>
                                    <div class="row">Little Princess Manicure<div class="price">$28</div>
                                        <ul>
                                            <li>On your head will be wearing a beautiful crown</li>
                                            <li>Special soak your hand with fresh milk.</li>
                                            <li>Your nails include: Cut, Clean, Shape, Sugar Smooth, Warm Cream Massage, Warm Towel + 2 Nails Design</li>
                                        </ul>  
                                    </div>
                                    <div class="row">Basic Pedicure<div class="price">$20</div>
                                        <ul>
                                            <li>Cut, Clean, Lotion Massage , and Polish</li>
                                        </ul>  
                                    </div>
                                    <div class="row">Little Miss Pedicure
                                        <ul>
                                            <li>Cut, Clean, Milk honey sugar, milk honey butter massage, hot hot towel, polish</li>
                                        </ul>  
                                    </div>
                                    <div class="row">Little Princess Pedicure
                                        <ul>
                                            <li>On your head will be wearing a beautiful crown</li>
                                            <li>Special soak your feet with fresh milk or jelly</li>
                                            <li>Cut, Clean, sugar smooth, warn cream massage, warm towel + 2 bigs toes design</li>
                                        </ul>  
                                    </div>
                                    <div class="row"> Polish change for Hand / Feet<div class="price">$5 / $7</div></div>
                                  
                                </div>
                           </div>
                        </div>
                    </div>

                    <a name="massage"></a>
                    <div id="ser5" class="groupservices">
                        <a name="massage-therapy"></a>
                        <div class="servicestitle">Massage Therapy</div>
                        <div class="servicestitle_note">All these manicure include cut, shaping, clean, hot towel, and polish.</div>
                        <div class="servicesbox">
                            <div class="servicesimg">
                                <img src="images/services/massage/1.png" alt="Massage Therapy" class="pedi_img" />
                                <!-- <img src="images/services/19.jpg" alt="Massage Therapy" class="pedi_img" />
                                <img src="images/services/20.jpg" alt="Massage Therapy" class="pedi_img clear_img" />
                                <img src="images/services/21.jpg" alt="Massage Therapy" class="pedi_img clear_img" />
                                <img src="images/services/22.jpg" alt="Massage Therapy" class="pedi_img clear_img" />
                                <img src="images/services/23.jpg" alt="Massage Therapy" class="pedi_img clear_img" /> -->
                            </div>
                            <div class="services_l">  
                                <div class="grouprow">   
                                    <div class="rowtitle">The Benefit Of Massage</div>      
                                    <div class="rowtitle_note">Decrease stress-Increase circulation-Release muscle tightness-Improve joint range of motion & flexibility-Release endorphins-Diminish aches & pains-Reduce anxiety & depression associated with: Anorexia & bulimia, posttraumatic stress disorder, chronic fatigue syndrome.</div>                                                
                                    <div class="row">Swedish Massage <div class="price">$60 | 30min--$80 | 60min -- $110 | 90min</div>
                                        <ul>
                                            <li>Gentle strokes work to improve circulation &amp; relax body. Using a combination of sliding and kneading movement, this traditional method of massage will ease away tension.</li>
                                        </ul>
                                    </div>                                   
                                    <div class="row">Lymph Drainage <div class="price">$50 | 30min -- $70 | 60min -- $95 | 90min</div>
                                        <ul>
                                            <li>Therapeutic technique that release chronic pain, slow strokes run across the muscles with deep finger pressure</li>
                                        </ul>
                                    </div>
                                    <div class="row">Deep Tissue Massage<div class="price">$70 | 30min--$95 | 60min--$140 | 90 min</div>
                                        <ul>
                                            <li>Helps loosen muscle tissues, release toxins from muscles and increase blood oxygen circulation. Focusing on the deeper layers of the muscles.</li>
                                        </ul>
                                    </div>
                                    <!-- <div class="row">Aromatherapy Body Massage<div class="price">$60 | 30min--$85 | 60min--$110 | 90min</div>
                                        <ul>
                                            <li>Relax while your smell since is delighted and your spirit is cleansed. Incorporating a blend of Swedish and lymphatic drainage techniques massage is used to apply an essential oil fomular prepared specifically for each individual quest. This special massage is ideal for restoring balance while obtoxifying and energizing the entire body.</li>
                                        </ul>
                                    </div>
                                    <div class="row">HOT STONE Therapy<div class="price">$75 | 30min--$105 | 60min--$150 | 90min</div>
                                        <ul>
                                            <li>A heavenly massage treatment that incorporated heated natural stones for penetrating heat into tight muscle as well as beneficial effects on the energy centers.</li>
                                        </ul>
                                    </div>
                                    <div class="row">Element of the Earth Warm Stone Massage<div class="price">$65 | 30min -- $95 | 60min -- $130 | 90min</div>
                                        <ul>
                                            <li>This treatment combines traditional Swedish massage with warm stone therapy. Emollient oils are gently applied, heated enabling our smooth heated river stones to glide over the skin. The warmth of the stones penetrates the muscle tissue, releasing tension and inducting deep relaxation.</li>
                                        </ul>
                                    </div>
                                    <div class="row">Sport Massage<div class="price">$65 | 30min--$100 | 60min--$140 | 90min</div>
                                        <ul>
                                            <li>Sport or work activity can sometimes cause stress on the body. A deep therapeutic massage which includes stretching that help reduce aches and pains.</li>
                                        </ul>
                                    </div>
                                    <div class="row">Couples Massage<div class="price">$100 | 30min -- $140 | 60min -- $190 | 90min</div>
                                        <ul>
                                            <li>Get in touch with the one you love, enjoy this romantic experience with the one you love. Relax to music and candlelight. Refreshing juice and cake to finish.</li>
                                            <li>With Warm Stone or Deep Tissue Massage -- $155 | 60min -- $220 | 90 min</li>
                                        </ul>
                                    </div>
                                    <div class="row">Mama To Be Massage<div class="price">$50 | 30min--$70 | 60min</div>
                                        <ul>
                                            <li>This massage benefits circulation, relieves the pain of overused muscle, and soothes nerves, feeling of relaxation.</li>
                                        </ul>
                                    </div>
                                    <div class="row">Chair Massage<div class="price">$20 | 10min--$30 | 15min--$55 | 30min</div>
                                        <ul>
                                            <li>Back, Neck, &amp; shoulder massage. Soothing massage that melts away tension from your day</li>
                                        </ul>
                                    </div>
                                    <div class="row">Couple massage<div class="price">$160/section for 2 people</div></div>
                                    <div class="row">HERBAL Hand &amp; Food Reflexolog<div class="price">$30 | 15min -- $50 | 30min -- $75 | 60min</div>
                                        <ul>
                                            <li>Reflexology is an ancient healing art based on the belief that the feet are mirrors of the body. Reflex points in the feet which correspond to various parts of the body are stimulated, which helps the body to balance and heal itself.</li>
                                        </ul>
                                    </div>
                                    <div class="row">Aromatherapy Scalp Massage<div class="price">$25 | 15min -- $45 | 30min</div>
                                        <ul>
                                            <li>SAUNA with light therapy SERVICE -- 15min | $20</li>
                                            <li>STEAM with aromatherapy SERVICE -- 15min | $20</li>
                                        </ul>
                                    </div>
                                    <div class="row">Benefit of Infrared Sauna
                                        <div class="rownote">
                                            Using the Healthy Infra-Red Sauna will help eliminating moisture, salt and subcutaneous fat from your body. Sweating is a part of complex thermo regulatory process of the body that increase the heart rate which consumes energy.
                                            <br/>At 110 fahrenheit degrees fat becomes water soluble and can be disposed of by sweating. A single sauna session may burn as many calories as jogging or rowing for 15 minutes. So you lose weight hot just water. The deep heat at the Healthy Infra-Red Sauna helps dilate blood vessels, bringing relief and healing to muscle and soft tissue injuries. This also increased blood circulation allows used extensively in the treatment of arthritis, rheumatism and muscle spasms and pain relief. It removed toxins like nicotine, alcohol, cholesterol and heavy metals like cadmium, lead, zinc, and nickel that accumulate in the system. The body removes them by perspiring. IR promotes detoxifying and cleaning capacity of the skin by stimulating the sweat glands. Visiting infrared sauna regularly can help lower elevated blood pressure and improve elasticity of the arteries.
                                        </div>
                                    </div>
                                    <div class="row">Benefits of Steam Showers
                                        <div class="rownote">
                                            Steam therapy help for you: Restful Sleep, Relaxation, alleviate cold symptoms, Sinusitis. Steam showers can be very beneficial for weight loss and general detoxification. When the body sweats due to steam from a shower or sauna, extra fluids and toxins are excreted through the skin. You will mainly lose water weight, so it is important to drink fluids before and after a steam show.
                                        </div>
                                    </div>                                     -->
                                </div>
                           </div>
                        </div>
                    </div>

                    

                </div>
            </div>

