
            <div class="groupcontent">
                <div class="content">
                    <h2>Products</h2>
                    <div class="groupproducts">
                        <div class="products"><img src="images/products/01.jpg" alt="products 1"/><div class="products_name">Guinot</div></div>
                        <div class="products"><img src="images/products/02.jpg" alt="products 1"/><div class="products_name">Dermalogica</div></div>
                        <div class="products"><img src="images/products/03.jpg" alt="products 1"/><div class="products_name">Moroccan Oil</div></div>
                        <div class="products"><img src="images/products/04.jpg" alt="products 1"/><div class="products_name">Paul Mitchell</div></div>
                        <div class="products"><img src="images/products/05.jpg" alt="products 1"/><div class="products_name">Goldwell</div></div>
                        <div class="products"><img src="images/products/06.jpg" alt="products 1"/><div class="products_name">O.P.I</div></div>
                        <div class="products"><img src="images/products/07.jpg" alt="products 1"/><div class="products_name">Cuccio Milk &amp; Honey Butter</div></div>
                        <div class="products"><img src="images/products/08.jpg" alt="products 1"/><div class="products_name">Organic Products</div></div>
                    </div> 
                    <!-- <div class="groupproducts_clip">
                        <div class="products_clip">
                           <iframe width="450" height="300" src="https://www.youtube.com/embed/vwk8eay9nAg" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                        </div>
                        <div class="products_clip">
                            <iframe width="450" height="300" src="https://www.youtube.com/embed/5zTkoqt-q24" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                        </div>
                        <div class="products_clip">
                           <iframe width="450" height="300" src="https://www.youtube.com/embed/BcUd8y9XlKw" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                        </div>
                        <div class="products_clip">
                            <iframe width="450" height="300" src="https://www.youtube.com/embed/wIWE210X1E8" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                        </div>

                    </div>  -->
                </div>
            </div>
