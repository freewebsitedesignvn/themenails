<link href="images/icon.png" rel="shortcut icon"/>

<link href="css/style.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="js/animation.js" type="text/javascript"></script>
<script type="text/javascript" src="scripts/soundplay.js"></script>
<script src="js/notification.js" type="text/javascript"></script>

<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600' rel='stylesheet' type='text/css'/>
<link href='http://fonts.googleapis.com/css?family=Cinzel+Decorative' rel='stylesheet' type='text/css'/>
<link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'/>
<link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow' rel='stylesheet' type='text/css'/>

<!--responsive web-->
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<!--[if lt IE 9]>
<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script><![endif]-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/customtheme.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
<!--end responsive web-->
