<div class="menu">
    <div class="menuimg"></div>
    <ul class="menu_m">   
        <li><a href="?p=home" class="selected">Home</a></li>
        <li><a href="?p=services">Services</a>
            <ul>
                <li><a href="?p=services#ser1">Nails Enhancement</a></li>
                <li><a href="?p=services#ser2">Manicure</a></li>
                <li><a href="?p=services#ser3">Pedicure</a></li>
                <li><a href="?p=services#ser4">Kid’s Services</a></li>
                <li><a href="?p=services#ser5">Massage Therapy</a></li>
                <li><a href="?p=services#ser6">Body Treatment</a></li>
                <li><a href="?p=services#ser7">Inch Loss Body Wrap</a></li>
                <li><a href="?p=services#ser8">Skin Care Services</a></li>
                <li><a href="?p=services#ser9">The Lift</a></li>
                <li><a href="?p=services#ser10">Hair Removal</a></li>
                <li><a href="?p=services#ser11">Threading Services</a></li>
                <li><a href="?p=services#ser12">Eyelash Extension</a></li>
                <li><a href="?p=services#ser13">Eyelash Tinting</a></li>
                <li><a href="?p=services#ser14">Permanent Makeup</a></li>
                <li><a href="?p=services#ser15">Hair Services</a></li>
            </ul>
        </li>
        <!-- <li><a href="?p=packages">Packages</a></li> -->
        <li><a href="?p=gallery">Gallery</a></li>
        <!-- <li><a href="?p=products">Products</a></li> -->
        <!-- <li><a href="?p=deals">Deals</a></li> -->
        <li><a href="?p=egift">E-Gift</a></li>
        <li class="menupromo"><a href="?p=promotions">Promotions</a></li>
        <li><a href="?p=reviews">Reviews</a></li>
        <li><a href="?p=location">Location</a></li>
        <li><a href="?p=jobs">Jobs</a></li>
        <li><a href="?p=contact">Contact</a></li>
    </ul>
</div>