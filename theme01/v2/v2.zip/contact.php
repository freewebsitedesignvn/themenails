

            <div class="groupcontent">
                <div class="content"  style="width:650px; color:#000;">
                    <h2>Contact Us</h2>
                    <div class="groupcontact">
                        <strong>Address:</strong> 1425 Stafford Market Place Stafford, VA 22556 
                        <br/>
                        <strong>Phone:</strong> (540) 659 - 3707
                        <br/>
                        <strong>Fax:</strong> (540) 659 - 4170
                    </div>

                                    <div class="contact_r">
                                        <!--Contact form Begin-->
                                        <div id="form">
                                            <div class="formrow">
                                                <div class="formrowtop">Your Name*:</div>
                                                <div class="formrowtext"><input class="txtbox" type="text" value="" id="txtName" placeholder="Your Name"/></div>
                                            </div>
                                            <div class="formrow">
                                                <div class="formrowtop">Your Email*:</div>
                                                <div class="formrowtext"><input class="txtbox" type="text" value="" id="txtEmail" placeholder="Your Email"/></div>
                                            </div>
                                            <div class="formrow">
                                                <div class="formrowtop">Phone Number*:</div>
                                                <div class="formrowtext"><input class="txtbox" type="text" value="" id="txtPhone" placeholder="999-999-9999"/></div>
                                            </div>
                                            <div class="formrow">
                                                <div class="formrowtop">Content*:</div>
                                                <div class="formrowtext"><textarea class="txtbox textarea" rows="10" value="" id="txtContent" placeholder="Message"/></textarea></div>
                                            </div>
                                            <div class="formrow buttonrow">
                                                <div id="formwait">Please wait...</div>
                                                <div id="bSend">Submit</div>
                                            </div>
                                            <!--opt notify-->
                                            <div id="formnotify">
                                                <div id="formnotifycontent">
                                                </div>
                                                <div id="formnotifyok">OK</div>
                                            </div>
                                            <!--opt notify-->
                                        </div>
                                        <!--Contact form End-->
                                    </div>     

                       </div>

                    </div>
