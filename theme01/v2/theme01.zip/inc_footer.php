<div class="groupcontent2">
                <div class="content">
                    <div class="home_l">
                        <div class="home_title">Other Information</div>
                        <!-- <div class="home_title">Daily Specials</div> -->
                        <div class="homepromo">
                            <!-- <a href="promotions"><img src="images/homepromo.png" alt="promotion 1"></a> -->
                        </div>
                    </div>
                     <div class="home_l">
                        <div class="home_title">Follow Us</div>
                        <!-- <div class="fb-like-box fb_iframe_widget" data-href="https://www.facebook.com/imperialsalonnspastafford" data-width="270" data-height="250" data-colorscheme="light" data-show-faces="false" data-header="false" data-stream="true" data-show-border="false" fb-xfbml-state="rendered" fb-iframe-plugin-query="app_id=1417198868538409&amp;color_scheme=light&amp;container_width=290&amp;header=false&amp;height=250&amp;href=https%3A%2F%2Fwww.facebook.com%2Fimperialsalonnspastafford&amp;locale=en_US&amp;sdk=joey&amp;show_border=false&amp;show_faces=false&amp;stream=true&amp;width=270"><span style="vertical-align: bottom; width: 270px; height: 250px;"><iframe name="f324a253fb0baf4" width="270px" height="250px" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" title="fb:like_box Facebook Social Plugin" src="https://www.facebook.com/v2.0/plugins/like_box.php?app_id=1417198868538409&amp;channel=http%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter%2Fr%2FbSTT5dUx9MY.js%3Fversion%3D42%23cb%3Df3d78b7e8a44f6c%26domain%3Dimperialsalonanddayspa.com%26origin%3Dhttp%253A%252F%252Fimperialsalonanddayspa.com%252Ffd75b54086863%26relation%3Dparent.parent&amp;color_scheme=light&amp;container_width=290&amp;header=false&amp;height=250&amp;href=https%3A%2F%2Fwww.facebook.com%2Fimperialsalonnspastafford&amp;locale=en_US&amp;sdk=joey&amp;show_border=false&amp;show_faces=false&amp;stream=true&amp;width=270" style="border: none; visibility: visible; width: 270px; height: 250px;" class=""></iframe></span></div> -->

                    </div>
                     <div class="home_r">
                        <div class="home_title">Hours &amp; Location</div>
                        <div class="home_r_box">
                            <div class="home_r_title">Adress:</div>
                            123 ABC Street, VA 123 
                            <br/>(123) 456 - 7890
                            <br />Please call for Appointment - Walk-ins Welcome!
                        </div>
                        <div class="home_r_box">
                            <div class="home_r_title">Hours:</div>
                            <strong>Mon - Sat:</strong> 9:00 am - 8:00 pm
                            <br/><strong>Sun:</strong>  10:00 am - 7:00 pm
                        </div>
                        <div class="home_r_box">
                            <div class="home_r_title">We Accept:</div>
                            <div>
                                <img src="images/visa.png" alt="visa" />
                                <img src="images/master.png" alt="master" />
                                <img src="images/discover.png" alt="discover" />
                                <img src="images/american.png" alt="american" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="groupfooter">
                <div class="footer">
                    <div class="footer_l">
                        Copyright © Data Global.
                    </div>
                    <div class="footer_r">
                        <a href="https://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a>
                        <a href="http://www.yelp.com/biz/" target="_blank"><img src="images/yelp.png" alt="Yelp" /></a>
                        
                    </div>

                </div>
            </div>
        </div>
        <!--<div class="groupdesigned">
              <a href="http://myesalon.com" target="_blank"><img src="images/designed.png" alt="myesalon"/></a>
              <a href="http://viethelpgroup.com" target="_blank"><img src="images/viethelpdesined.png" alt="myesalon"/></a>
        </div>-->
    </div>
    <div id="flag">1</div>

    <!-- <a href="sign-up" id="subbar"><img src="images/subbar.png" alt="Subscribe"/></a> -->
    <div class="groupfbye">
        <a href="https://www.facebook.com/" target="_blank"><img src="images/facebook_icon.png" /></a>
        <div class="line"></div>
        <a href="http://www.yelp.com/biz/" target="_blank"> <img src="images/yelp_icon1.png" /></a>  
        <div class="line"></div>
        <a href="https://www.google.com/" target="_blank" class="facebookbar"><img src="images/gp_icon.png" /></a>
    </div>

    <div id="gotop"></div>