
            <div class="groupcontent">
                <div class="content">
                    <h2>Signature Spa Packages</h2>

                    <div class="groupservices">
                        <div class="servicesbox">
                            <div class="servicesimg">
                                <img src="images/packages/1.jpg" alt="packages 1" class="pedi_img" />
                                <img src="images/packages/2.jpg" alt="packages 2" class="pedi_img" />
                                <img src="images/packages/3.jpg" alt="packages 3" class="pedi_img clear_img" />
                                <img src="images/packages/4.jpg" alt="packages 4" class="pedi_img clear_img" />
                                <img src="images/packages/5.jpg" alt="packages 4" class="pedi_img clear_img" />
                                <img src="images/packages/6.jpg" alt="packages 5" class="pedi_img clear_img" />
                                <img src="images/packages/7.jpg" alt="packages 6" class="pedi_img clear_img" />
                                <img src="images/packages/8.jpg" alt="bridal" class="bridal_img clear_img" />
                            </div>
                            <div class="services_l">  
                                <div class="grouprow">                              
                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">Mini Day Of Beauty</div><div class="packageprice">$185 | 2.5 hours (valued at $200)</div>
                                        </div>
                                        <ul>
                                            <li> Natural nuskin Manicure $30</li>
                                            <li> SMOOTH Natural nuskin pedicure $45</li>
                                            <li> Beauty Neuve Facial – 60 min $115</li>
                                            <li> Eyebrows Wax $10</li>

                                        </ul>
                                    </div>
                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">Lady's Exclusive</div><div class="packageprice">$245 | 3 hours (valued at $275)</div>
                                        </div>
                                        <ul>
                                            <li>Paradisal Deluxe Manicure $40</li>
                                            <li>Fire worker healthy Pedicure $75</li>
                                            <li>1 hour Swedish Massage $80</li>
                                            <li>Age loc facial spa $80</li>

                                        </ul>
                                    </div>
                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">Winter Wonderland Package</div><div class="packageprice">$280 | 3 hours (valued at $295)</div>
                                        </div>
                                        <ul>
                                            <li>Ice dancer healthy manicure + gel Polish $60</li>
                                            <li>Warm Stone Therapy Massage – 60 min $105</li>
                                            <li>Age smart skin care $130</li>

                                        </ul>
                                    </div>
                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">The Great Spa</div><div class="packageprice">$270 | 3.5 hours (valued at $290)</div>
                                        </div>
                                        <ul>
                                            <li>Imperial spa Manicure $35</li>
                                            <li>Fire worker healthy pedicure $75</li>
                                            <li>Aroma Therapy Massage – 60 min $85</li>
                                            <li>Ultracaming $95</li>
                                            <li>Free Light Lunch</li>

                                        </ul>
                                    </div>
                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">Day Of Imperial</div><div class="packageprice">$320 | 4 hours (valued at $335)</div>
                                        </div>
                                        <ul>
                                            <li>Natural nuskin manicure + gel polish ($50)</li>
                                            <li>Paradisal deluxe pedicure $75</li>
                                            <li>Seaweed Body Wrap $95</li>
                                            <li>Beaute Neuve Facial $115</li>
                                            <li>Light Lunch</li>

                                        </ul>
                                    </div>
                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">The Sweet Day Package</div><div class="packageprice">$355 | 4 hours (valued at $390)</div>
                                        </div>
                                        <ul>
                                            <li>Pink &amp; White full set OPI la $60</li>
                                            <li>Peppermint Pedicure $75</li>
                                            <li>Eyebrows Wax $10</li>
                                            <li>Swedish Massage – 60 min $80</li>
                                            <li>Supper Hydradermie skin care $165</li>
                                            <li>Light Lunch</li>

                                        </ul>
                                    </div>
                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">REVITALIZER PACKAGE</div><div class="packageprice">$305 | 5 hours (valued at $317)</div>
                                        </div>
                                        <ul>
                                            <li>Full Set OPI Set UL Gel</li>
                                            <li>Ocean Spa Pedicure</li>
                                            <li>Element of the Earth Warm Stone Massage – 1 hour</li>
                                            <li>Express Facial</li>
                                            <li>Eyebrow Wax</li>
                                            <li>Shampoo, Blow Dry, Style</li>
                                            <li>Light Lunch</li>
                                        </ul>
                                    </div>
                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">Special Occasion</div><div class="packageprice">$445 | 5 hours (valued at $485)</div>
                                        </div>
                                        <ul>
                                            <li>Full Set Gel $40</li>
                                            <li>Fire worker healthy pedicure $75</li>
                                            <li>Swedish Massage – 60 min $80</li>
                                            <li>Facelifting guinot skin care $160</li>
                                            <li>South Pacific body Treatment $130</li>
                                            <li>Light Lunch</li>

                                        </ul>
                                    </div>

                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">VIP Signature Package</div><div class="packageprice">$510 | 5.5 hours (valued at $560)</div>
                                        </div>
                                        <ul>
                                            <li>VIP signature manicure $60</li>
                                            <li>VIP signature pedicure $100</li>
                                            <li>Sauna Therapy $20</li>
                                            <li>Body Scrub and seaweed Wrap $150</li>
                                            <li>Aromatherapy Body Massage – 1 hour $80</li>
                                            <li>OXYGEN young skin care $150</li>
                                            <li>Light Lunch</li>

                                        </ul>
                                    </div>

                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">CITY ESCAPE I</div><div class="packageprice">$378 | 5.5 hours (valued at $385)</div>
                                        </div>
                                        <ul>
                                            <li>Almond &amp; Pearl Mask Spa Pedicure</li>
                                            <li>Sauna Therapy</li>
                                            <li>South Pacific Treatment</li>
                                            <li>Aromatherapy Body Massage – 1 hour</li>
                                            <li>Microdemabrasion Treatment Facial</li>
                                            <li>Eyebrows Wax</li>
                                            <li>Light Lunch</li>
                                        </ul>
                                    </div>
                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">Lap Of Luxury</div><div class="packageprice">$428 | 5.5 hours (valued at $45)</div>
                                        </div>
                                        <ul>
                                            <li>Full Set Pink &amp; White Liquid Gel</li>
                                            <li>Steam</li>
                                            <li>IONIC FOOT DETOX with a perfect pedicure</li>
                                            <li>Peel &amp; Reveal Revitalizing Treatment Facial</li>
                                            <li>Eyeylash Extention last up to 4 weeks</li>
                                            <li>Full Face Waxing</li>
                                            <li>Light Lunch</li>
                                        </ul>
                                    </div>
                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">Couples Spa Package</div><div class="packageprice">$418 | 2.5 hours (valued at $430)</div>
                                        </div>
                                        <ul>
                                            <li>Organic Pedicure</li>
                                            <li>AGE Smart Treatment Facial</li>
                                            <li>Two Swedish Body Massage - 1 hour</li>
                                            <li>Light Lunch</li>                                            
                                        </ul>
                                    </div>
                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">Ultimate Day Heavenly Package</div><div class="packageprice">$460 | 6 hours (valued at $490)</div>
                                        </div>
                                        <ul>
                                            <li>Sauna or Steam</li>
                                            <li>Aromatic Body Treatment for Cellulite and De-toxing</li>
                                            <li>Liftosome Facial</li>
                                            <li>Imperial Spa Manicure with French Gel Polish</li>
                                            <li>VIP SIGNATURE PEDICURE</li>      
                                            <li>Eyebrows Shaping</li>
                                            <li>Shampoo, Blow Dry, and Style</li>    
                                            <li>Light Lunch</li>                                                      
                                        </ul>
                                    </div>
                                    <div class="row">
                                        <div class="packagegroup">
                                            <div class="packagetitle">Bridal Package</div><div class="packageprice">$550 (valued price $700)</div>
                                        </div>
                                        <br />
                                        Your walk down the aisle begins at Imperial Salon &amp; Day Spa. At imperial salon & day Spa, your special day is as important to us as it is to you. We have designed a variety of wonderful ways for you to look and feel beautiful as you begin your walk down the aisle.
                                        <br /><br />From massages to bridal makeup…from facials to fabulous body treatments, hair-styling and manicures (got to show off that ring!) we lavish our brides-to-be from head to toe. Our exclusively-created six-month Countdown to “I Do” is an absolute must to guarantee that wedding “wow!” And take a look at our unique Bridal Spa Packages (we haven’t forgotten the groom!) and wedding party spa-celebrations.
                                        <br /><br />If you want to radiate inside AND out, come say, “I do” to a imperial SPA Bridal Spa Day.
                                        <ul>
                                            <li>Facial for bridal:
                                                <ul>
                                                    <li>An intensive exfoliatation with a ‘peeling effect’, which results in fresh, new skin. The Beaute Nueve targets dull, sallow complexions, fine lines, reduces pigmentation deeply exfoliates to remove dead skin cells and sun-damaged skin through the action of fruit acids and fruit enzymes.The result is skin that looks smooth, rested, and glowing, as if you had just returned from a holiday. Leave skin white and natural, smooth and youthful, minimizing pores and refining skin.</li>
                                                </ul>
                                            </li>
                                            <li>COMPLIMENTARY BRIDAL MAKEUP APPLICATION</li>
                                            <li>BRIDAL UPDOS </li>
                                            <li>HEAVEN on EARTH Manicure for bridal</li>
                                            <li>PARADISAL DELUXE Pedicure for bridal</li>      
                                            <li>BRIDAL EYELASH EXTENSION individual lash</li>                                                    
                                        </ul>
                                    </div>

                                </div>

                                
                           </div>
                        </div>
                    </div>


                </div>
            </div>
