 <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Dosis" rel="stylesheet"/>
    <link rel="stylesheet" href="./css/core.min.css">
    <link rel="stylesheet" href="./css/main.css">
    <script src="./js/core.js"></script>
    <script src="./js/main.js"></script>