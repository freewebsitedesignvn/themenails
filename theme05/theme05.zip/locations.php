
      <div class="home_box">
        <div class="content">
          <h2 id="title">Location<span>Nail Salon</span></h2>
        </div>
      </div>
      <div class="groupcontent">
        <div class="content_box">
          <div class="content content_pages">
            <h2>Our Location</h2>
            <!-- <div class="servicesnav"><a href="location"><<Back to Contact List</a></div> -->
            <div class="grouplocation">
              <div class="location_l">
                <div class="location_title">Information</div>
                <strong>Address:</strong> 123 ABC Street, VA 123 <br>
                <strong>Phone:</strong><a href="tel:(123) 456 - 7890">(123) 456 - 7890</a><br><br>
                <div class="location_title">Hours </div>                            
                Monday - Friday: 9am - 8pm <br>                            
                Saturday: 9am - 7pm <br>                            
                Sunday: 11am - 5pm
              </div>
              <!-- <div class="location_r">
                <div class="location_title">Stay Connected</div><a href="https://www.facebook.com/tipsyofjupiter" target="_blank"><img src="images/contact/facebook.png" alt="facebook"></a><a href="https://www.instagram.com/tipsysalonbar/" target="_blank"><img src="images/contact/instagram.png" alt="instagram"></a><a href="https://plus.google.com/110452645256945986861" target="_blank"><img src="images/contact/google.png" alt="Google Plus"></a><a href="https://www.yelp.com/biz/tipsy-salon-and-spa-jupiter-jupiter-2" target="_blank"><img src="images/contact/yelp.png" alt="Yelp"></a>
              </div> -->
            </div>
            <div class="map">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2345.8770519046416!2d-117.95378818968437!3d33.745904118688756!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80dd27be9256e4fb%3A0xaa6fa85e0281e6d6!2s10161+Bolsa+Ave+%23207A%2C+Westminster%2C+CA+92683!5e0!3m2!1svi!2s!4v1535436330992" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
            <!-- <div class="streetview">
              <iframe src="https://www.google.com/maps/embed?pb=!1m0!3m2!1sen!2sus!4v1473665153081!6m8!1m7!1sQaWLUSucJ8NRo0GnPTT5Rg!2m2!1d26.89119049009039!2d-80.10293438428444!3f14!4f2!5f0.7820865974627469" width="100%" height="400" frameborder="0" style="border:0" allowfullscreen=""></iframe>
            </div> -->
          </div>
        </div>
      </div>