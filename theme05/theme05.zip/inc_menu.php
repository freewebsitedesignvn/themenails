<div class="header_m">
            <div class="groupmenu_m">
              <ul>
                <li id="call_m"><a href="tel:5616266074"><span>Call</span></a></li>
                <li id="email_m"><a href="?p=email"><span>Email</span></a></li>
                <li id="direction_m"><a href="?p=locations"><span>Direction</span></a></li>
                <li id="subbar_m"><a href="?p=sign-up"><span>Stay Connected</span></a></li>
              </ul>
            </div>
          </div>
          <div class="menu">
            <ul class="menu_m">
              <li class="menuimg">Menu</li>
              <li><a class="selected" href="?p=home">Home</a>
              </li>
              <li><a href="?p=services">Services</a>
               <!--  <ul>
                  <li><a href="detail-services.html">Jupiter</a>
                  </li>
                  <li><a href="detail-services.html">Boynton Beach</a>
                  </li>
                  <li><a href="detail-services.html">Fort Lauderdale</a>
                  </li>
                  <li><a href="detail-services.html">Deerfield Beach</a>
                  </li>
                </ul> -->
              </li>
              <li><a href="?p=promotions">Promotions</a>
              </li>
              <li><a href="?p=join-our-team">Join Our Team</a>
              </li>
              <li><a href="?p=e-gift">Gift Card</a>
              </li>
              <!-- <li><a href="partnership.html">Partnership</a> -->
              </li>
              <li><a href="?p=locations">Locations</a>
                <!-- <ul>
                  <li><a href="detail-locations.html">Jupiter</a>
                  </li>
                  <li><a href="detail-locations.html">Boynton Beach</a>
                  </li>
                  <li><a href="detail-locations.html">Fort Lauderdale</a>
                  </li>
                  <li><a href="detail-locations.html">Deerfield Beach</a>
                  </li>
                  <li><a href="detail-locations.html">Plantation</a>
                  </li>
                  <li><a href="detail-locations.html">Winter Park</a>
                  </li>
                </ul> -->
              </li>
            </ul>
          </div>