<div class="home_box">
        <div class="content">
          <h2 id="title">Stay Connected<span>Nail Salon</span></h2>
        </div>
      </div>
      <div class="groupcontent">
        <div class="content_box">
          <div class="content content_pages">
            <div class="sign">
              <div class="sign_title">Sign Up to receive future promotions & birthday gifts to your inbox. </div>
              <div id="formsign">
                <div class="formrow">
                  <div class="formrowtop">First Name <span style="color: Red;">*</span>:</div>
                  <div class="formrowtext">
                    <input class="txtboxsign" id="txtFirstName" type="text" value="" placeholder="Your First Name">
                  </div>
                </div>
                <div class="formrow">
                  <div class="formrowtop">Last Name:</div>
                  <div class="formrowtext">
                    <input class="txtboxsign" id="txtLastName" type="text" value="" placeholder="Your Last Name">
                  </div>
                </div>
                <div class="formrow">
                  <div class="formrowtop">Email <span style="color: Red;">*</span>:</div>
                  <div class="formrowtext">
                    <input class="txtboxsign" id="txtEmail" type="text" value="" placeholder="Your Email">
                  </div>
                </div>
                <div class="formrow">
                  <div class="formrowtop">Phone:</div>
                  <div class="formrowtext">
                    <input class="txtboxsign" id="txtPhone" type="text" value="" placeholder="999-999-9999">
                  </div>
                </div>
                <div class="formrow">
                  <div class="formrowtop">Birthdate:</div>
                  <div class="formrowtext">
                    <input class="txtboxsign" id="datepicker" type="text" value="" placeholder="MM-DD">
                  </div>
                </div>
                <div class="formrow buttonrow">
                  <div id="bSubmit">Submit</div>
                  <div id="waitdiv" style="display: none;">Please wait...</div>
                </div>
                <div id="formnotify">
                  <div id="formnotifycontent"></div>
                  <div id="formnotifyok">OK</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>