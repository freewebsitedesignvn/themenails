<div class="groupfooter">
        <div class="content">
          <div class="footer_box">
            <div class="footer_logo"><a href="index.html"><img src="images/logo_black.png" alt=""></a></div>
            <center>
            <div class="home_l">
              <div class="home_loca_title">Nail Salon</div>
              123 ABC Street, VA 123 <br>
              (123) 456 - 7890  
              <div class="social"><a href="https://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook"></a><a href="https://www.instagram.com/" target="_blank"><img src="images/instagram.png" alt="instagram"></a><a href="https://plus.google.com/" target="_blank"><img src="images/googleplus.png" alt="Google Plus"></a><a href="https://www.yelp.com/biz/" target="_blank"><img src="images/yelp.png" alt="Yelp"></a></div><a class="learnmore" href="?p=locations">Location</a>
            </div>
            </center>
           <!--  <div class="home_l">
              <div class="home_loca_title">Boynton Beach</div>                        2240 N Congress Ave Boynton Beach, FL 33426 <br>                        (561) 742-2272  
              <div class="social"><a href="https://www.facebook.com/tipsyboynton/" target="_blank"><img src="images/facebook.png" alt="facebook"></a><a href="https://www.instagram.com/tipsysalonbar/" target="_blank"><img src="images/instagram.png" alt="instagram"></a><a href="https://plus.google.com/100007472290110299775/posts" target="_blank"><img src="images/googleplus.png" alt="Google Plus"></a><a href="https://www.yelp.com/biz/tipsy-salonbar-boynton-beach-3" target="_blank"><img src="images/yelp.png" alt="Yelp"></a></div><a class="learnmore" href="locations.html">Location</a>
            </div>
            <div class="home_l">
              <div class="home_loca_title">Deerfield Beach</div>                        1660 SE 3rd Ct, Deerfield Beach, FL 33441<br>                        (954) 427-0313
              <div class="social"><a href="https://www.facebook.com/TipsyDeerfield" target="_blank"><img src="images/facebook.png" alt="facebook"></a><a href="https://www.instagram.com/tipsysalonbar/" target="_blank"><img src="images/instagram.png" alt="instagram"></a><a href="https://plus.google.com/+TipsySalonbarDeerfieldBeach/about" target="_blank"><img src="images/googleplus.png" alt="Google Plus"></a><a href="https://www.yelp.com/biz/tipsy-salonbar-deerfield-beach" target="_blank"><img src="images/yelp.png" alt="Yelp"></a></div><a class="learnmore" href="locations.html">Location</a>
            </div>
            <div class="home_l">
              <div class="home_loca_title">Fort Lauderdale</div>                        1503 E Las Olas Blvd Fort Lauderdale, FL 33301 <br>                        (954) 779-2616
              <div class="social"><a href="https://www.facebook.com/tipsysalonbarlasolas" target="_blank"><img src="images/facebook.png" alt="facebook"></a><a href="https://www.instagram.com/tipsysalonbar/" target="_blank"><img src="images/instagram.png" alt="instagram"></a><a href="https://plus.google.com/101146126692430236996/about" target="_blank"><img src="images/googleplus.png" alt="Google Plus"></a><a href="https://www.yelp.com/biz/tipsy-salonbar-fort-lauderdale-2" target="_blank"><img src="images/yelp.png" alt="Yelp"></a></div><a class="learnmore" href="locations.html">Location</a>
            </div>
            <div class="home_l">
              <div class="home_loca_title">Plantation</div><span style=" font-size:9pt;">The Fountains, 801 S University Dr C-120, Plantation, FL 33324</span><br>                        (954) 472-8860
              <div class="social"><a href="#" target="_blank"><img src="images/facebook.png" alt="facebook"></a><a href="https://www.instagram.com/tipsysalonbar/" target="_blank"><img src="images/instagram.png" alt="instagram"></a><a href="#" target="_blank"><img src="images/googleplus.png" alt="Google Plus"></a><a href="#" target="_blank"><img src="images/yelp.png" alt="Yelp"></a></div><a class="learnmore" href="locations.html">Location</a>
            </div>
            <div class="home_r">
              <div class="home_loca_title">Winter Park</div><span style=" font-size:10pt;">110 S. Orlando Ave Suite 8 Winterpark, FL 32789</span><br>                        (407) 543-3456
              <div class="social"><a href="https://www.facebook.com/tipsysalonbarwinterpark/" target="_blank"><img src="images/facebook.png" alt="facebook"></a><a href="https://www.instagram.com/tipsysalonbar.winterpark/" target="_blank"><img src="images/instagram.png" alt="instagram"></a><a href="https://plus.google.com/108378551138627423726" target="_blank"><img src="images/googleplus.png" alt="Google Plus"></a><a href="https://www.yelp.com/biz/tipsy-salonbar-orlando" target="_blank"><img src="images/yelp.png" alt="Yelp"></a></div><a class="learnmore" href="locations.html">Location</a>
            </div> -->
          </div>
        </div>
        <div class="copyright">Copyright © Nail Salon</div>
      </div>