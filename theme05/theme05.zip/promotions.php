<div class="home_box">
  <div class="content">
    <h2 id="title">Promotions:</h2>
  </div>
</div>
<div class="groupcontent">
  <div class="content text-center">
  	<?php for($i=1;$i<=7;$i++){?>
    <div class="grouppro mb-2">
      <div class="proimg"><img alt="" src="images/promotions/<?php echo $i?>.jpg"></div><a target="_blank" href="images/promotions/<?php echo $i?>.jpg"><img class="mt-2" src="images/print.png" alt="print"></a>
    </div>
    <?php } ?>
   <!--  <div class="grouppro mb-2">
      <div class="proimg"><img alt="" src="images/promotion2.jpg"></div><a target="_blank" href="promotions.html"><img class="mt-2" src="images/print.png" alt="print"></a>
    </div> -->
  </div>
</div>