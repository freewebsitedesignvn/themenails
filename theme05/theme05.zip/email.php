 <div class="home_box">
        <div class="content">
          <h2 id="title">Email Us<span>Nail Salon</span></h2>
        </div>
      </div>
      <div class="groupcontent">
        <div class="content_box">
          <div class="content content_pages">
            <div class="contact_from_title">Send us a message</div>
            <div id="form">
              <div class="formrow">
                <div class="formrowtop">Your Name*:</div>
                <div class="formrowtext">
                  <input class="txtbox" id="txtName" type="text" value="" placeholder="Your Name">
                </div>
              </div>
              <div class="formrow">
                <div class="formrowtop">Your Email*:</div>
                <div class="formrowtext">
                  <input class="txtbox" id="txtEmail" type="text" value="" placeholder="Your Email">
                </div>
              </div>
              <div class="formrow">
                <div class="formrowtop">Phone Number*:</div>
                <div class="formrowtext">
                  <input class="txtbox" id="txtPhone" type="text" value="" placeholder="999-999-9999">
                </div>
              </div>
              <div class="formrow">
                <div class="formrowtop">Content*:</div>
                <div class="formrowtext">
                  <textarea class="txtbox textarea" id="txtContent" rows="10" value="" placeholder="Message"></textarea>
                </div>
              </div>
              <div class="formrow buttonrow">
                <div id="formwait">Please wait...</div>
                <div id="bSend">Submit</div>
              </div>
              <div id="formnotify">
                <div id="formnotifycontent"></div>
                <div id="formnotifyok">OK</div>
              </div>
            </div>
          </div>
        </div>
      </div>