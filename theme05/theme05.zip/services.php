<div class="home_box">
  <div class="content">
    <h2 id="title">Services<span>Nail Salon</span></h2>
  </div>
</div>
<div class="groupcontent">
        <div class="content_box">
          <div class="content content_pages"><a name="nail-services"></a>
            <div class="groupservices">
              <!-- <div class="servicesnav"><a href="services.html"><< Back to Service List</a></div>
              <div class="servicestitle">Nails Services</div> -->
              <div class="grouprow">
                <div class="rowtitle">Hands</div>
                <div class="row">Basic Manicure
                  <div class="price">$15</div>
                </div>
                <div class="row">Scented Cocktail Manicure
                  <div class="price">$20</div>
                </div>
                <div class="row">Aromatherapy Manicure
                  <div class="price">$25</div>
                </div>
                <div class="row">Signatural Manicure
                  <div class="price">$35</div>
                </div>
                <div class="row">Shellac Gel Manicure
                  <div class="price">$30</div>
                </div>
                <div class="services_border"><img src="images/bg_services.png" alt=""></div>
              </div>
              <!-- <div class="grouprow" style="margin-top:20px;">
                <div class="rowtitle">Feet</div>
                <div class="row">Basic Pedicure (30 min)
                  <div class="price">$30</div>
                </div>
                <div class="row">Cocktail Pedicure (45 min)
                  <div class="price">$40</div>
                </div>
                <div class="row">Aromatherapy Pedicure (45 min)
                  <div class="price">$45</div>
                </div>
                <div class="row">Pearl Spa Pedicure (50 min)
                  <div class="price">$55</div>
                </div>
                <div class="row">Tipsy Signature Spa Pedicure (60 min)
                  <div class="price">$65</div>
                </div>
                <div class="row">Hot Stone Spa Pedicure (75 min)
                  <div class="price">$75</div>
                </div>
              </div> -->
              <div class="grouprow" style="margin-top:20px;">
                <div class="rowtitle">Nail Extensions</div>
                <div class="row">Acrylic Full Set
                  <div class="price">$28 +</div>
                </div>
                <div class="row">Acrylic Fill
                  <div class="price">$17 +</div>
                </div>
                <div class="row">Gel Powder Full Set
                  <div class="price">$38 +</div>
                </div>
                <div class="row">Gel Powder Fill
                  <div class="price">$25 +</div>
                </div>
                <div class="row">Pink & White Full Set
                  <div class="price">$55 +</div>
                </div>
                <div class="row">Pink & White Fill
                  <div class="price">$38 +</div>
                </div>
                <div class="row">Pink Pill
                  <div class="price">$30 +</div>
                </div>
                <div class="services_border"><img src="images/bg_services.png" alt=""></div>
              </div>
              <!-- <div class="grouprow" style="margin-top:20px;">
                <div class="rowtitle">Dip-It</div>
                <div class="row">Regular Full Set
                  <div class="price">$40</div>
                </div>
                <div class="row">Regular Fill
                  <div class="price">$30</div>
                </div>
                <div class="row">Pink & White Full Set
                  <div class="price">$50</div>
                </div>
                <div class="row">Pink & White Fill
                  <div class="price">$38</div>
                </div>
              </div> -->
              <!-- <div class="grouprow" style="margin-top:20px;">
                <div class="rowtitle">Additional Indulgences</div>
                <div class="row">Nail Repair/Cut Down
                  <div class="price">$3 +</div>
                </div>
                <div class="row">Polish Change Hands
                  <div class="price">$10</div>
                </div>
                <div class="row">Polish Change Feet
                  <div class="price">$16</div>
                </div>
                <div class="row">French
                  <div class="price">$6</div>
                </div>
                <div class="row">Nails Art
                  <div class="price">$5 +</div>
                </div>
                <div class="row">Buff to Shine
                  <div class="price">$5</div>
                </div>
              </div>
                <div class="services_border"><img src="images/bg_services.png" alt=""></div> -->
            </div>
<!--             <div class="groupservices">
              <div class="servicestitle">Hair Services</div>
              <div class="grouprow">
                <div class="row">Cut & Style Women
                  <div class="price">$60 & Up</div>
                </div>
                <div class="row">Blow Dry
                  <div class="price">$35 & Up</div>
                </div>
                <div class="row">Flat Iron Only
                  <div class="price">$20 & Up</div>
                </div>
                <div class="row">Consultation Hair Extensions
                  <div class="price">Free</div>
                </div>
                <div class="row">Children Under 12
                  <div class="price">$25</div>
                </div>
                <div class="row">Up–Do's
                  <div class="price">$70 & Up</div>
                </div>
                <div class="row">Men’s Cut
                  <div class="price">$30 & Up</div>
                </div>
                <div class="row">Davines Natural Tech Treatment
                  <div class="price">$20 & Up</div>
                </div>
                <div class="row">Deep Conditioning Treatment
                  <div class="price">$20 & Up</div>
                </div>
              </div>
              <div class="grouprow" style="margin-top:20px;">
                <div class="rowtitle">Color</div>
                <div class="row">Single Process Color
                  <div class="price">$60 & Up</div>
                </div>
                <div class="row">Full Color
                  <div class="price">$90 & Up</div>
                </div>
                <div class="row">Glaze/Toner
                  <div class="price">$35 & Up</div>
                </div>
                <div class="row">Partial Highlights
                  <div class="price">$90 & Up</div>
                </div>
                <div class="row">Full Highlights
                  <div class="price">$120 & Up</div>
                </div>
                <div class="row">Brow Tint
                  <div class="price">$20 & Up</div>
                </div>
                <div class="row">Men’s Balayage
                  <div class="price">$35 & Up</div>
                </div>
                <div class="row">Permanent
                  <div class="price">$55 & Up</div>
                </div>
              </div>
              <div class="grouprow" style="margin-top:20px;">
                <div class="rowtitle">Hair Treatments</div>
                <div class="row">Express Blowout Keratin
                  <div class="price">$120 & Up</div>
                  <div class="row_note">(Last up to 6 weeks)</div>
                </div>
                <div class="row">Keratin Full Term Treatment
                  <div class="price">$250 & Up</div>
                </div>
                <div class="row">Cezanne Keratin
                  <div class="price">$250 & Up</div>
                  <div class="row_note">(Formaildehyde Free)</div>
                </div>
              </div>
              <div class="grouprow" style="margin-top:20px;">
                <div class="rowtitle">Ouidad – Curly Hair</div>
                <div class="row">Ouidad Cut Only
                  <div class="price">$100</div>
                </div>
                <div class="row">Ouidad Cut + Style
                  <div class="price">$120</div>
                </div>
              </div>
              <div class="grouprow" style="margin-top:20px;">
                <div class="rowtitle">Hair Extensions</div>
                <div class="row_note" style="text-align:center;">By Consultation Only. Call Us.</div>
                <div class="row">Micro Link</div>
                <div class="row">Great Lengths</div>
                <div class="row">Socap</div>
                <div class="row">Hand Tied</div>
                <div class="row">Tape In</div>
              </div>
              <div class="services_border"><img src="images/bg_services.png" alt=""></div>
            </div> -->
            <div class="groupservices">
              <div class="servicestitle">Waxing</div>
              <div class="grouprow">
                <div class="row">Eye Brow
                  <div class="price">$10</div>
                </div>
                <div class="row">Lip or Chin
                  <div class="price">$8</div>
                </div>
                <div class="row">Side Burn
                  <div class="price">$12</div>
                </div>
                <div class="row">Full Face
                  <div class="price">$45</div>
                </div>
                <div class="row">Half Arm
                  <div class="price">$25</div>
                </div>
                <div class="row">Full Arm
                  <div class="price">$40</div>
                </div>
                <div class="row">Under Arm
                  <div class="price">$20</div>
                </div>
                <div class="row">Chest
                  <div class="price">$40 & Up</div>
                </div>
                <div class="row">Back
                  <div class="price">$50 & Up</div>
                </div>
                <div class="row">Half Leg
                  <div class="price">$35</div>
                </div>
                <div class="row">Full Leg
                  <div class="price">$35</div>
                </div>
                <div class="row">Bikini
                  <div class="price">$30</div>
                </div>
                <div class="row">Brazillian
                  <div class="price">$60 & Up</div>
                </div>
                <div class="row">Stomach/Abdomen
                  <div class="price">$25</div>
                </div>
                <div class="row">Brow Tint
                  <div class="price">$20</div>
                </div>
                <div class="row">Lash Tint
                  <div class="price">$25</div>
                </div>
              </div>
            </div>
            <!-- <div class="groupservices">
              <div class="servicestitle">Sugaring</div>
              <div class="grouprow">
                <div class="row">Half Arm
                  <div class="price">$30</div>
                </div>
                <div class="row">Full Arm
                  <div class="price">$50</div>
                </div>
                <div class="row">Half Leg
                  <div class="price">$40</div>
                </div>
                <div class="row">Full Leg
                  <div class="price">$70</div>
                </div>
                <div class="row">Bikini
                  <div class="price">$35 & Up</div>
                </div>
                <div class="row">Brazilian
                  <div class="price">$65 & Up</div>
                </div>
                <div class="row">Underarm
                  <div class="price">$30</div>
                </div>
                <div class="row">Stomach/Abdomen
                  <div class="price">$25 & Up</div>
                </div>
                <div class="row">Men’s  Neck Line
                  <div class="price">$20</div>
                </div>
                <div class="row">Men’s Shoulder
                  <div class="price">$30 & Up</div>
                </div>
                <div class="row">Men’s Chest
                  <div class="price">$40 & Up</div>
                </div>
                <div class="row">Men’s Back
                  <div class="price">$65 & Up</div>
                </div>
                <div class="row">Men’s Nose
                  <div class="price">$10</div>
                </div>
                <div class="row">Men’s Ears
                  <div class="price">$10 & Up</div>
                </div>
              </div>
              <div class="services_border"><img src="images/bg_services.png" alt=""></div>
            </div> -->
            <!-- <div class="groupservices">
              <div class="servicestitle">Threading</div>
              <div class="grouprow">
                <div class="row">Eye Brow
                  <div class="price">$14</div>
                </div>
                <div class="row">Lip or Chin
                  <div class="price">$12</div>
                </div>
                <div class="row">Full Face
                  <div class="price">$65 & Up</div>
                </div>
                <div class="row">Side Burn
                  <div class="price">$45 & Up</div>
                </div>
              </div>
              <div class="services_border"><img src="images/bg_services.png" alt=""></div>
            </div> -->
            <div class="groupservices">
              <div class="servicestitle">Skin Care / Facials</div>
              <div class="grouprow">
                <div class="row">Express Facial (30 min)
                  <div class="price">$35</div>
                </div>
                <div class="row">European Deep Cleansing Facial (60 min)
                  <div class="price">$80</div>
                </div>
                <div class="row">Detox Gel Deep Pore Treatment & Extraction (60 min)
                  <div class="price">$80</div>
                </div>
                <div class="row">Teen Acne Facial (60 min)
                  <div class="price">$80</div>
                </div>
                <div class="row">Gentlemen’s Facial (60 min)
                  <div class="price">$80</div>
                </div>
                <div class="row">Age Later Signature Facial (70 Min)
                  <div class="price">$130</div>
                </div>
                <div class="row">Organic Passion Peptide Peel (60 min)
                  <div class="price">$100</div>
                </div>
                <div class="row">Microdermabrasion Treatment (60 min)
                  <div class="price">$100</div>
                </div>
                <div class="row">Dual Peel (80 Min)
                  <div class="price">$160</div>
                </div>
                <div class="row">Signature Face Lift (60min)
                  <div class="price">$115</div>
                </div>
                <div class="row">Winkle Lift (60 min)
                  <div class="price">$115</div>
                  <div class="row_note">(All level of aging skin & pigmentation disorders)</div>
                </div>
                <div class="row">Beta/Acne Lift 50 min)
                  <div class="price">$115</div>
                </div>
                <div class="row">Back Facial (60min)
                  <div class="price">$75</div>
                </div>
              </div>
              <div class="services_border"><img src="images/bg_services.png" alt=""></div>
            </div>
            <!-- <div class="groupservices">
              <div class="servicestitle">Body Massage</div>
              <div class="grouprow">
                <div class="row">Sweedish
                  <div class="row_note">25mins - $50<br>                                        50mins - $75<br>                                        80mins - $100</div>
                </div>
                <div class="row">Aromatherapy Massage
                  <div class="row_note">25mins - $50<br>                                        50mins - $80<br>                                        80mins - $140</div>
                </div>
                <div class="row">Hot Stone “Muscle Melt”
                  <div class="row_note">25mins - $75<br>                                        50mins - $110<br>                                        80mins - $160</div>
                </div>
                <div class="row">“Mommy-to-be” Pre-Natal Massage
                  <div class="row_note">50mins - $100</div>
                </div>
                <div class="row">Reflexology
                  <div class="row_note">25mins - $55<br>                                        50mins - $95</div>
                </div>
                <div class="row">Deep Tissue Massage
                  <div class="row_note">25mins - $60<br>                                        50mins - $90<br>                                        80mins - $140</div>
                </div>
              </div>
              <div class="services_border"><img src="images/bg_services.png" alt=""></div>
            </div> -->
            <!-- <div class="groupservices">
              <div class="servicestitle">Permanent Makeup</div>
              <div class="grouprow">
                <div class="row">Correction
                  <div class="price">$300 +</div>
                </div>
                <div class="row">Eyebrow
                  <div class="price">$400</div>
                </div>
                <div class="row">Eyebrow Feathering
                  <div class="price">$600</div>
                </div>
                <div class="row">Eye Liner (Both)
                  <div class="price">$450</div>
                </div>
                <div class="row">Eye Liner (one)
                  <div class="price">$250</div>
                </div>
                <div class="row">Full Lip
                  <div class="price">$700</div>
                </div>
                <div class="row">Lip Liner
                  <div class="price">$400</div>
                </div>
                <div class="row">Special Event Makeup
                  <div class="price">$75</div>
                </div>
              </div>
              <div class="services_border"><img src="images/bg_services.png" alt=""></div>
            </div> -->
           <!--  <div class="groupservices">
              <div class="servicestitle">Eyelash Extensions</div>
              <div class="grouprow">
                <div class="row">Individual – Full Set
                  <div class="price">$200 +</div>
                </div>
                <div class="row">Individual – Fill
                  <div class="price">$80 +</div>
                </div>
                <div class="row">Group Lashes – Full Set
                  <div class="price">$45 +</div>
                </div>
                <div class="row">Group Lashes – Fill
                  <div class="price">$25 +</div>
                </div>
              </div>
              <div class="services_border"><img src="images/bg_services.png" alt=""></div>
            </div><a name="additional-services"></a> -->
            <!-- <div class="groupservices">
              <div class="servicestitle">Additional Services</div>
              <div class="grouprow">
                <div class="row">Medspa Services
                  <div class="price">Call for consultation</div>
                </div>
                <div class="row">Botox
                  <div class="price">Call for consultation</div>
                </div>
                <div class="row">Dermal Filler
                  <div class="price">Call for consultation</div>
                </div>
                <div class="row">Coolsculpting
                  <div class="price">Call for consultation</div>
                </div>
                <div class="row">IV Hydration
                  <div class="price">Call for consultation</div>
                </div>
              </div>
              <div class="services_border"><img src="images/bg_services.png" alt=""></div>
            </div> -->
          </div>
        </div>
      </div>