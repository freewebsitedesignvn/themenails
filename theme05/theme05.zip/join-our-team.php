<div class="home_box">
        <div class="content">
          <h2 id="title">Join Our Team<span>Nail Salon</span></h2>
        </div>
      </div>
      <div class="groupcontent">
        <div class="content_box">
          <div class="content content_pages">
            <div class="solutions_img2"><img src="images/join1.jpg" alt="join"><img src="images/join2.jpg" alt="join"><img src="images/join3.jpg" alt="join"></div>
            <p style="text-align:center;">Nail Salon is looking to hire new talent for hair, nails, skin, and massage. Please contact us for more information at <a href="mailto:info@nailsalon.com">info@nailsalon.com</a>.</p>
          </div>
        </div>
      </div>